<?php
include_once "Connection.php";
$obj = new Connection();
$conn = $obj->getConnection();

$cuts = array("Good"=>"g","Very Good" => "vg","Ideal" => "i","Astor Ideal" => "ai");
$colors = array("J"=>'j',"I"=>"i","H"=>"h","G"=>"g","F"=>"f","E"=>"e","D"=>"d");
$claritys = array("SI2"=>"si2","SI1"=>"si1","VS2"=>"vs2","VS1"=>"vs1","VVS2"=>"VVS2","VVS1"=>"vvs1","IF"=>"if","FL"=>"fl");
$polishs = array("G"=>"g","VG"=>"vg","EX" => "ex");
$symmetrys = array("G"=>"g","VG"=>"vg","EX" => "ex");
$fluorescences = array("Very Strong" => "vsb","Strong" => "sb","Med." => "mb","Faint" => "faint","None / Neg."=> "none");

$round = "";
if(isset($_REQUEST['round'])){
    $round = $_REQUEST['round'];
}
$princess = "";
if(isset($_REQUEST['princess'])){
    $round = $_REQUEST['princess'];
}
$emerald = "";
if(isset($_REQUEST['emerald'])){
    $round = $_REQUEST['emerald'];
}
$asscher = "";
if(isset($_REQUEST['asscher'])){
    $round = $_REQUEST['asscher'];
}
$cushion = "";
if(isset($_REQUEST['cushion'])){
    $round = $_REQUEST['cushion'];
}
$marquise = "";
if(isset($_REQUEST['marquise'])){
    $round = $_REQUEST['marquise'];
}
$radiant = "";
if(isset($_REQUEST['radiant'])){
    $round = $_REQUEST['radiant'];
}
$oval = "";
if(isset($_REQUEST['oval'])){
    $round = $_REQUEST['oval'];
}
$pear = "";
if(isset($_REQUEST['pear'])){
    $round = $_REQUEST['pear'];
}
$heart = "";
if(isset($_REQUEST['heart'])){
    $round = $_REQUEST['heart'];
}
$qshape = "shape IN (";
    if(isset($_REQUEST['round'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['princess'])){
        $qshape .= "'Princess' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['emerald'])){
        $qshape .= "'Emerald' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['asscher'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['cushion'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['marquise'])){
        $qshape .= "'Marquise' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['radiant'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['oval'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['pear'])){
        $qshape .= "'' ,";
    }else{
        $qshape .= "'' ,";
    }
    if(isset($_REQUEST['heart'])){
        $qshape .= "''";
    }else{
        $qshape .= "''";
    }
$qshape .= " )";

$color = explode(";",$_REQUEST['color']); // Strings
$clarity = explode(";",$_REQUEST['clarity']); // Strings
$ratio = array(0,10000);
if (isset($_REQUEST['ratio'])){
    $ratio = explode(";",$_REQUEST['ratio']); // Numbers
}
$depth = array(0,10000);
if (isset($_REQUEST['depth'])){
    $depth = explode(";",$_REQUEST['depth']); // Numbers
}
$table = array(0,10000);
if (isset($_REQUEST['table'])){
    $table = explode(";",$_REQUEST['table']); // Numbers
}
$cut = explode(";",$_REQUEST['cut']); // Strings
$polish = array("G","EX");
if (isset($_REQUEST['polish'])){
    $polish = explode(";",$_REQUEST['polish']); // Strings
}
$symmetry = array("G","EX");
if (isset($_REQUEST['symmetry'])){
    $symmetry = explode(";",$_REQUEST['symmetry']); // Strings
}
$fluorescence = array("Very Strong","None / Neg.");
if (isset($_REQUEST['fluorescence'])){
    $fluorescence = explode(";",$_REQUEST['fluorescence']); // Strings
}
$price = explode(";",$_REQUEST['price']); // Numbers
//$carat = "";

$qratio = "ratio BETWEEN $ratio[0] AND $ratio[1]";
$qdepth = "depth BETWEEN $depth[0] AND $depth[1]";
$qtable = "tbl BETWEEN $table[0] AND $table[1]";
$qprice = "orgprice BETWEEN $price[0] AND $price[1]";

// CUT Start
$is= array();
foreach($cut as $item){
    $i = 0;
    foreach ($cuts as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$cut = array_slice($cuts,$is[0],$is[1]);
$qcut = "cut IN (";
$lastind = end($cut);
foreach($cut as $key => $item){
    $qcut .= "'".$item ."'";
    if ($item != $lastind){
        $qcut .= " ,";
    }
}
$qcut .= " )";
// Cut END

// Color Start
$is= array();
foreach($color as $item){
    $i = 0;
    foreach ($colors as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$color = array_slice($colors,$is[0],$is[1]);
$qcolor = "color IN (";
$lastind = end($color);
foreach($color as $key => $item){
    $qcolor .= "'".$item ."'";
    if ($item != $lastind){
        $qcolor .= " ,";
    }
}
$qcolor .= " )";
// Color End

// Clarity Start
$is= array();
foreach($clarity as $item){
    $i = 0;
    foreach ($claritys as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$clarity = array_slice($claritys,$is[0],$is[1]);
$qclarity = "clarity IN (";
$lastind = end($clarity);
foreach($clarity as $key => $item){
    $qclarity .= "'".$item ."'";
    if ($item != $lastind){
        $qclarity .= " ,";
    }
}
$qclarity .= " )";
// Clarity End

// Polish Start
$is= array();
foreach($polish as $item){
    $i = 0;
    foreach ($polishs as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$polish = array_slice($polishs,$is[0],$is[1]);
$qpolish = "polish IN (";
$lastind = end($polish);
foreach($polish as $key => $item){
    $qpolish .= "'".$item ."'";
    if ($item != $lastind){
        $qpolish .= " ,";
    }
}
$qpolish .= " )";
// Polish End

// Symmetry Start
$is= array();
foreach($symmetry as $item){
    $i = 0;
    foreach ($symmetrys as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$symmetry = array_slice($symmetrys,$is[0],$is[1]);
$qsymmetry = "symmetry IN (";
$lastind = end($symmetry);
foreach($symmetry as $key => $item){
    $qsymmetry .= "'".$item ."'";
    if ($item != $lastind){
        $qsymmetry .= " ,";
    }
}
$qsymmetry .= " )";
// Symmetry End

// Fluorescence Start
$is= array();
foreach($fluorescence as $item){
    $i = 0;
    foreach ($fluorescences as $key => $inner){
        if ($item == $key){
            array_push($is,$i);
            break;
        }
        $i++;
    }
}
$fluorescence = array_slice($fluorescences,$is[0],$is[1]);
$qfluorescence = "fluorescence IN (";
$lastind = end($fluorescence);
foreach($fluorescence as $key => $item){
    $qfluorescence .= "'".$item ."'";
    if ($item != $lastind){
        $qfluorescence .= " ,";
    }
}
$qfluorescence .= " )";
// Fluorescence End

$query = "SELECT * FROM round_diamonds WHERE ( $qshape AND $qprice )  AND ( $qclarity OR $qcolor OR $qdepth OR $qfluorescence OR $qpolish OR $qcut OR $qsymmetry OR $qtable )";

//echo $query ."<br><br>";

$stmt = $conn->prepare($query);
$stmt->execute();
$data = $stmt->fetchAll();

$count = 1;
$start = '';


foreach ($data as $item){
    $start .= '<tr>
                <td>'.$count.'</td>
                <td>'.$item["shape"].'</td>
                <td>$'.$item["orgprice"].'</td>
                <td>'.$item["cut"].'</td>
                <td>'.$item["color"].'</td>
                <td>'.$item["clarity"].'</td>
            </tr>';
}


echo $start;

/*
 * shape
 * color
 * clarity
 * ratio
 * depth
 * table
 * cut
 * polish
 * symmetry
 * fluorescence
 * orgprice
 * price/pricepercarat = carat
 * */



